<?php
	
	// Loader - class and connection
	include('loader.php');
	
	if(isset($_GET['token']) && $_GET['token'] == $_SESSION['token'])
	{
		$c = $calendar->get_event($_POST['id']);
		if($calendar->check($_POST, $c))
		{
			$content = $c['description'];
			$cat = $c['category'];
			$color = $c['color'];
			
			if($cat == '') { $cat = 'General'; }
			
			if($content == '') { $content = '$null'; } else {
				$content = $formater->html_format($embed->oembed($content));
				$content = $maps->to_maps($content);	
			} 
			
			$content_editable = $c['description'];
			
			if($color == '') { $color = '$null'; }
			
			$array = array('description' => $content, 'description_editable' => $content_editable, 'category' => $cat, 'categorie' => $cat, 'all-day' => $c['allDay'], 'color' => $color, 'categories' => $calendar->categories);
			
			unset($c['description'], $c['category'], $c['categorie'], $c['color'], $c['allDay']);
			
			$nc = array();
			foreach($c as $ck => $cv)
			{
				if($calendar->is_serialized($cv))
				{
					$unser = unserialize($cv);
					$unser = array_filter($unser);
					$nc[$ck] = $unser;
				} else {
					$nc[$ck] = $cv;
				}
			}
			
			$array = array_merge($array, $nc);
			
			if($content == true)
			{
				if(isset($_POST['mode']) && $_POST['mode'] == 'edit')
				{	
					echo json_encode($array);
				} else {
					echo $content_editable;
				}
			} else {
				echo '';
			}
		}
	}
	
?>