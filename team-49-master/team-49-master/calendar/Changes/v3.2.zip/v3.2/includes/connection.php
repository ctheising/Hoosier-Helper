<?php
	
	// DB Connection Configuration
	define('DB_HOST', 'localhost'); 
	define('DB_USERNAME', 'root'); 
	define('DB_PASSWORD', ''); 
	define('DATABASE', 'calendar'); 
	define('TABLE', 'calendar');
	define('USERS_TABLE', 'users');
	
	// Path to the files for upload
	define('SITE_FILES_URL', 'http://localhost/calendar-2.2.16/files/');

	// Default Categories
	$categories = array("General", "Party", "Work", "Letters & Arts");
	
	/*
	Only applied for non user versions
	Should (non admin versions) display user events from the database?
	 true - does not display user events 
	 false - will display all events on the database even private ones on non admin versions (e.g: "Simple")
	*/
	define('PUBLIC_PRIVATE_EVENTS', true);
	
	// Feature to import events
	define('IMPORT_EVENTS', true);
	
?>
